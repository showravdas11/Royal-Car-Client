import React from 'react';

const Payment = () => {
    return (
        <div>
            <h2>Payment Method Coming Soon..........</h2>
            <img className="img-fluid" src="https://i.ibb.co/51wPKVg/Credit-Card-Payment-cuate-1.png" alt="" />
        </div>
    );
};

export default Payment;