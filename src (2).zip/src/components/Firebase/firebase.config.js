const firebaseConfig = {
    apiKey: "AIzaSyCU7EIhl79sxN6xDVfCNR2e1qQ1yqGiXZc",
    authDomain: "royal-car-314b7.firebaseapp.com",
    projectId: "royal-car-314b7",
    storageBucket: "royal-car-314b7.appspot.com",
    messagingSenderId: "983513736288",
    appId: "1:983513736288:web:5751b60739b3bcb9834f05"
};

export default firebaseConfig;